# 📊 Centralized Data Organizer_v01.xlsm

Centralized Data Organizer is a macro-enabled Excel tool designed to help users manage dynamic categories and records with ease. Built entirely in VBA, this application provides a user-friendly interface for creating, updating, and organizing structured data—all within Excel.

---

## 🚀 Features

### 🔧 Category Management
- Add up to 12 custom categories (e.g., Email, City, Phone Number)
- Delete unused or outdated categories
### 📝 Record Entry
- Add new records using a responsive form
- Fields adjust automatically to match current categories
### 🔍 Record Update Tools
- **Search**: Filter records by category and keyword
- **Replace**: Modify field values only when changes are detected
- **Delete**: Remove selected records from both the table and preview list
### 🎯 UX Enhancements
- Prompts for missing data with placeholder guidance
- Auto-clear placeholder text when typing begins

---

## 📦 File Contents

- `Centralized Data Organizer_v01.xlsm` – Main Excel macro-enabled file
- `README.md` – Project documentation
- `CHANGELOG.md` – Version history and feature log

---

## 📜 Version History

See [`CHANGELOG.md`](CHANGELOG.md) for detailed updates.

---

## 🛠 Requirements

- Microsoft Excel 365 (with macro support enabled)
- VBA enabled (developed using the Microsoft 365 VBA environment)
- No external dependencies

---

## 📚 Usage

1. Unblock the `.xlsm` file in the properties under the General tab.
2. Open the `.xlsm` file and enable macros.
3. Use the **Main Form** to navigate between:
   - Category Management: Add or Delete Categories (Up to 12)
   - Record Management: Entry, Search, Replace, Delete
4. Use the **Quit** button to exit the form safely.

---

## 👨‍💻 Author

**James**  
Date Created: October 1, 2025

---

## 📬 Feedback & Contributions

Feel free to fork, improve, or suggest enhancements via GitHub Issues or Pull Requests. This project is designed to be modular and extendable.

