Before opening, Unblock the file first:
1. Right-click the 'Real-Time Currency Converter.xlsm' file.
2. Click Properties
3. Check the UnBlock box.
4. Click Apply.
5. Click OK.
You can now use it!